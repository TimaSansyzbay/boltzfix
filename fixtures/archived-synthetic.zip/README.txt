BoltzFix run bundle. Synthetic runs are NOT scientific results. No experimental reference is included. Artifact hashes are in run.json. Timing is observed service latency, not GPU time.
